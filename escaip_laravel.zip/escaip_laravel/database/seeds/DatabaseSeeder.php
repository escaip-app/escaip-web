<?php

use Illuminate\Database\Seeder;
use App\User;
use App\Post;
use App\Category;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for($c = 0; $c < 5; $c++){
            $category = Category::fake();
            $category->save();
        }
        for($i = 0; $i < 5; $i++){
            $user = User::fake();
            $user->save();
            $nbPost = rand(0, 8);
            $category_id = rand(1, 5);
            for($j = 0; $j < $nbPost; $j++){
                $post = Post::fake($user->id, $category_id);
                $post->save();
            }
        }
        // $this->call(UsersTableSeeder::class);
    }
}
