<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    public function posts(){
        return $this->hasMany('App\Post');
    }

    static public function fake() {
        $f = \Faker\Factory::create('fr_CA');
        $resultat = new self();
        $resultat->title = $f->jobTitle();
        $resultat->slug = str_slug($resultat->title, "");
        return $resultat;
    }
}
