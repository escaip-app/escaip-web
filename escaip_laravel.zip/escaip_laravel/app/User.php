<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'first_name', 'last_name', 'school', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function posts(){
        return $this->hasMany('App\Post');
    }

    /**
     * check if the user is an admin
     */
    public static function admin(){
        $admin = Auth::user()->level_admin;
        return $admin;
    }

    static public function fake() {
        $f = \Faker\Factory::create('fr_CA');
        $resultat = new self();
        $resultat->last_name = $f->lastName();
        $resultat->first_name = $f->firstName();
        $resultat->name = str_slug($resultat->first_name.$resultat->last_name, "");
        $resultat->password = str_slug($resultat->first_name.$resultat->last_name, "");
        $resultat->email = $resultat->name.'@'.$f->domainName();
        $resultat->description = $f->paragraph();
        $resultat->school = 'CSTJ';
        return $resultat;
    }
}
