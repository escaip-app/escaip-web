<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = ['title', 'slug', 'content', 'user_id', 'category_id'];
    
    public function category(){
        return $this->belongsTo('App\Category');
    }

    public function user(){
        return $this->belongsTo('App\User');
    }
    static public function fake($user_id, $category_id) {
        $f = \Faker\Factory::create('fr_CA');
        $resultat = new self();
        $resultat->title = $f->text($maxNbChars = 50);
        $resultat->slug = str_slug($resultat->title, "");
        $resultat->content = $f->paragraph();
        $resultat->user_id = $user_id;
        $resultat->category_id = $category_id;
        return $resultat;
    }
}
