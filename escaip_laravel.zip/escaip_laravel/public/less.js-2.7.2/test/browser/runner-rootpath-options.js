var less = {logLevel: 4,
    errorReporting: "console"};
less.rootpath = "https://localhost/";
